Sangaboard Microscope Stage
===========================

.. automodule:: openflexure_microscope.stage.sanga
    :members: