Base Streaming Camera
=======================================================

.. automodule:: openflexure_microscope.camera.base
    :members: