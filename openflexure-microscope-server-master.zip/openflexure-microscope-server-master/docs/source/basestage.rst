Base Microscope Stage
=====================

.. automodule:: openflexure_microscope.stage.base
    :members: