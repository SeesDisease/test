module.exports = {
  outputDir: '../openflexure_microscope/api/static/dist',
};
