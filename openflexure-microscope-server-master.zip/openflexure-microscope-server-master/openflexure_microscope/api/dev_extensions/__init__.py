from .tools import DevToolsExtension

LABTHINGS_EXTENSIONS = [DevToolsExtension]
